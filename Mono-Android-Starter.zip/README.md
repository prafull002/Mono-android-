# Mono Android starter

This is a native Android starter for Mono. It has a minimal black-and-white Home/Inbox UI and an Android NotificationListenerService that stores Instagram notification previews locally.

## Honest capability limits
- It can read notification previews only after the user explicitly enables Android Notification Access.
- It cannot fetch the private Instagram home feed, friends' Stories, complete DM history, or send DMs.
- It does not ask for or store an Instagram password.
- Notification previews may be hidden by Android/Instagram privacy settings and may contain sensitive content. Keep this app private and revoke notification access any time.

## Build an APK without Android Studio (GitHub Actions)
1. Create a GitHub account if you do not already have one.
2. Create a new repository named `mono-android`.
3. Upload the contents of this project (not the outer folder) to the repository.
4. Open the repository's **Actions** tab.
5. Choose **Build Mono APK** and tap **Run workflow** (or push the files to `main`).
6. When it finishes, open the workflow run, scroll to **Artifacts**, and download `mono-debug-apk`.
7. Extract the downloaded artifact and install `app-debug.apk` on your Android phone. Android may ask permission to install from that browser/file manager.

## First run
1. Open Mono.
2. Go to Inbox.
3. Tap **Open Notification Access Settings**.
4. Enable **Mono notification reader**.
5. Ask your spare Instagram account to send a test DM notification.
6. Open Mono > Inbox and tap Refresh Notifications.

This starter is for testing only; it is not a full Instagram client.
