package com.mono.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private LinearLayout content;
    private String currentTab = "Home";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showScreen();
    }

    private TextView text(String value, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(Color.BLACK);
        t.setTextSize(size);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(0, 10, 0, 10);
        return t;
    }

    private void showScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 28, 24, 18);
        root.setBackgroundColor(Color.WHITE);

        TextView brand = text("mono", 32, true);
        root.addView(brand);
        TextView tagline = text("A quieter place for your conversations.", 14, false);
        tagline.setTextColor(Color.DKGRAY);
        root.addView(tagline);

        LinearLayout tabs = new LinearLayout(this);
        Button home = new Button(this); home.setText("HOME");
        Button inbox = new Button(this); inbox.setText("INBOX");
        tabs.addView(home, new LinearLayout.LayoutParams(0, -2, 1));
        tabs.addView(inbox, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(tabs);
        home.setOnClickListener(v -> { currentTab = "Home"; showScreen(); });
        inbox.setOnClickListener(v -> { currentTab = "Inbox"; showScreen(); });

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 18, 0, 18);
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        if ("Home".equals(currentTab)) {
            content.addView(text("FRIENDS STORIES", 13, true));
            content.addView(text("Your friends' stories will appear here when an app provides them. Instagram does not expose private Stories to Mono.", 16, false));
            content.addView(text("FRIENDS POSTS", 13, true));
            content.addView(text("Your friends' posts are not available through Android notifications. This space is ready for future Mono features.", 16, false));
            content.addView(text("No Explore tab. No endless feed.", 14, true));
        } else {
            content.addView(text("INBOX", 22, true));
            content.addView(text("Mono can show Instagram message notification previews after you grant notification access. It cannot fetch your full inbox or send messages.", 15, false));
            Button access = new Button(this);
            access.setText("OPEN NOTIFICATION ACCESS SETTINGS");
            content.addView(access);
            access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
            Button refresh = new Button(this);
            refresh.setText("REFRESH NOTIFICATIONS");
            content.addView(refresh);
            refresh.setOnClickListener(v -> showScreen());
            content.addView(text("RECENT MESSAGE NOTIFICATIONS", 13, true));
            for (String item : NotificationStore.getAll(this)) {
                TextView row = text(item, 15, false);
                row.setBackgroundColor(0xFFF2F2F2);
                row.setPadding(14, 14, 14, 14);
                content.addView(row);
                View gap = new View(this);
                content.addView(gap, new LinearLayout.LayoutParams(1, 8));
            }
            if (NotificationStore.getAll(this).isEmpty()) {
                content.addView(text("No Instagram notifications yet. Ask your test account to send you a message while Instagram notifications are enabled.", 15, false));
            }
        }
        setContentView(root);
    }
}
