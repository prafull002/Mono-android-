package com.mono.app;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.List;

public class NotificationStore {
    private static final String PREF = "mono_notifications";
    public static void add(Context c, String value) {
        SharedPreferences p = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        String old = p.getString("items", "");
        String updated = value.replace("\n", " ").trim() + "\n---\n" + old;
        String[] parts = updated.split("\\n---\\n");
        StringBuilder limited = new StringBuilder();
        for (int i = 0; i < Math.min(parts.length, 50); i++) {
            if (i > 0) limited.append("\n---\n");
            limited.append(parts[i]);
        }
        p.edit().putString("items", limited.toString()).apply();
    }
    public static List<String> getAll(Context c) {
        String raw = c.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString("items", "");
        List<String> out = new ArrayList<>();
        if (!raw.isEmpty()) {
            for (String s : raw.split("\\n---\\n")) if (!s.trim().isEmpty()) out.add(s);
        }
        return out;
    }
}
